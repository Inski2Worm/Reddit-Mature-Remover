from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

chrome_options = Options()
# chrome_options.add_argument("--remote-debugging-port=9222")
# chrome_options.add_argument(r"user-data-dir=C:\Users\inski\AppData\Local\Google\Chrome\User Data")

def wait_for_captcha():

    counter = 0

    while True:

        counter = counter + 1    
        print("Timeout counter = ", counter)

        current_url = driver.current_url
        print(f"Current URL: {current_url}")

        if "?captcha=1" in current_url:
            print("Captcha has been solved, sleeping for 2 seconds and proceeding.")
            time.sleep(1)
            print("1...")
            time.sleep(1)
            print("2...")
            break

        if counter >= 10:
            print("Captcha timed out or no captcha is present, sleeping for 2 seconds and attempting to proceed.")
            time.sleep(1)
            print("1...")
            time.sleep(1)
            print("2...")
            break

        time.sleep(2)


try:
    driver = webdriver.Chrome(options=chrome_options)
    driver.get('https://www.reddit.com/r/hentai')

    print("Solve the CAPTCHA.")

    wait_for_captcha()

    #input()  # Wait for user input to continue

    print("Waiting for the blocking modal...")
    element = WebDriverWait(driver, 30).until(
        EC.presence_of_element_located((By.ID, "blocking-modal"))
    )

    print("Modal found. Removing it...")
    driver.execute_script("arguments[0].parentNode.removeChild(arguments[0]);", element)
    print("Modal removed.")

    print("Waiting for the qr...")
    element = WebDriverWait(driver, 30).until(
        EC.presence_of_element_located((By.ID, "nsfw-qr-dialog"))
    )

    print("Qr found. Removing it...")
    driver.execute_script("arguments[0].parentNode.removeChild(arguments[0]);", element)
    print("Qr removed.")

    print("Keeping the browser open indefinitely. Close the window manually when done.")
    while True:
        time.sleep(1)

except Exception as e:
    print(f"An error occurred: {e}")








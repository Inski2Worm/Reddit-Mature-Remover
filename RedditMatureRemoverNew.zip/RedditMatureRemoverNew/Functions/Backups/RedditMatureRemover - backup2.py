from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from pathlib import Path
import os
import time

chrome_options = Options()
WebAddress = ''
FileLocation = Path(__file__).resolve()
ProjectDirectory = FileLocation.parent.parent

def find_captcha_prescense():
    try:
        driver.find_element(By.CLASS_NAME, "g-recaptcha")
        return True
    except NoSuchElementException:
        return False

def wait_for_captcha_dissappear():
    while True:
        if not find_captcha_prescense():
            print("No captcha detected, sleeping for 2 second(s) and then proceeding.")
            time.sleep(1)
            print("No captcha detected, sleeping for 1 second(s) and then proceeding.")
            time.sleep(1)
            break
        else:
            print("Waiting for captcha to be solved...")
            time.sleep(2)

def get_addr():
    try:

        TxtDir = os.path.join(ProjectDirectory, "WebAddress.txt")

        with open(TxtDir, 'r') as file:
            WebAddress = file.readline().strip()

            if WebAddress:
                return WebAddress
            else:
                print("The file WebAddress is empty.")
    except FileNotFoundError:
        print("The file WebAddress has not been found.")
    except Exception as e:
        print(f"An error occurred: {e}")

try:
    driver = webdriver.Chrome(options=chrome_options)
    WebAddress = get_addr()
    driver.get(WebAddress)

    wait_for_captcha_dissappear()

    print("Stage 1 waiting...")
    element = WebDriverWait(driver, 30).until(
        EC.presence_of_element_located((By.ID, "blocking-modal"))
    )

    driver.execute_script("arguments[0].parentNode.removeChild(arguments[0]);", element)
    print("Stage 1 removed.")

    print("Stage 2 waiting...")
    element = WebDriverWait(driver, 30).until(
        EC.presence_of_element_located((By.ID, "nsfw-qr-dialog"))
    )

    print("Stage 2 removed.")
    driver.execute_script("arguments[0].parentNode.removeChild(arguments[0]);", element)

    while True:
        time.sleep(1)

except Exception as e:
    print(f"An error occurred: {e}")


























































